"""Password pattern checks and entropy estimation."""
import math
import re


COMMON_PASSWORDS = {
    "password", "123456", "12345678", "qwerty",
    "admin", "password123", "iloveyou",
}

SEQUENCES = (
    "abcdefghijklmnopqrstuvwxyz",
    "0123456789",
    "qwertyuiop",
    "asdfghjkl",
    "zxcvbnm",
)


def estimate_entropy(password: str) -> float:
    """Estimate theoretical entropy from observed character categories.

    This is only a rough estimate. It cannot know how the password was chosen.
    """
    pool_size = 0
    if any(char.islower() for char in password):
        pool_size += 26
    if any(char.isupper() for char in password):
        pool_size += 26
    if any(char.isdigit() for char in password):
        pool_size += 10
    if any(not char.isalnum() for char in password):
        pool_size += 32

    if not password or not pool_size:
        return 0.0
    return len(password) * math.log2(pool_size)


def has_sequence(password: str) -> bool:
    text = password.lower()
    for sequence in SEQUENCES:
        for index in range(len(sequence) - 2):
            part = sequence[index:index + 3]
            if part in text or part[::-1] in text:
                return True
    return False


def has_repeated_pattern(password: str) -> bool:
    """Detect passwords made entirely from a short repeated unit."""
    if len(password) < 4:
        return False
    for size in range(1, len(password) // 2 + 1):
        if len(password) % size == 0:
            unit = password[:size]
            if unit * (len(password) // size) == password:
                return True
    return False


def security_warnings(password: str) -> list[str]:
    warnings = []
    if password.lower() in COMMON_PASSWORDS:
        warnings.append("This is a commonly used password.")
    if len(password) >= 3 and len(set(password)) == 1:
        warnings.append("Avoid repeating a single character.")
    if has_sequence(password):
        warnings.append("Avoid keyboard or alphabetical sequences.")
    if has_repeated_pattern(password):
        warnings.append("Avoid repeating the same short pattern.")
    return warnings
