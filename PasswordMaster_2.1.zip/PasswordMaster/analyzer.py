"""Password strength analysis."""
from security import estimate_entropy, security_warnings


def analyze_password(password: str) -> dict:
    """Return a transparent heuristic score and recommendations.

    The score is educational, not a guarantee that a password is secure.
    """
    if not isinstance(password, str):
        raise TypeError("Password must be text.")

    score = 0
    tips = []
    length = len(password)
    entropy = estimate_entropy(password)

    if length >= 16:
        score += 30
    elif length >= 12:
        score += 25
    elif length >= 8:
        score += 15
    else:
        score += 5
        tips.append("Use at least 12 characters.")

    categories = {
        "lowercase": any(char.islower() for char in password),
        "uppercase": any(char.isupper() for char in password),
        "numbers": any(char.isdigit() for char in password),
        "symbols": any(not char.isalnum() for char in password),
    }
    score += sum(categories.values()) * 10

    if not categories["lowercase"]:
        tips.append("Add lowercase letters.")
    if not categories["uppercase"]:
        tips.append("Add uppercase letters.")
    if not categories["numbers"]:
        tips.append("Add numbers.")
    if not categories["symbols"]:
        tips.append("Consider adding special characters.")

    # Entropy contributes to the score, but cannot validate how a password
    # was actually chosen.
    score += min(30, int(entropy / 3))

    warnings = security_warnings(password)
    if password.lower() in {
        "password", "123456", "12345678", "qwerty",
        "admin", "password123", "iloveyou",
    }:
        score = 0
    if any("single character" in warning for warning in warnings):
        score = min(score, 10)
    if any("sequences" in warning for warning in warnings):
        score -= 15
    if any("short pattern" in warning for warning in warnings):
        score -= 15

    tips.extend(warnings)
    score = max(0, min(score, 100))

    return {
        "score": score,
        "entropy": entropy,
        "length": length,
        "categories": categories,
        "tips": tips,
    }


def get_rating(score: int) -> tuple[str, str]:
    from settings import RED, YELLOW, BLUE, GREEN

    if score < 30:
        return "VERY WEAK", RED
    if score < 50:
        return "WEAK", YELLOW
    if score < 70:
        return "MODERATE", "#e6d85c"
    if score < 90:
        return "STRONG", BLUE
    return "EXCELLENT", GREEN
