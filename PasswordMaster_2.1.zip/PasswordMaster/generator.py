"""Cryptographically secure password generation."""
import secrets
import string

from settings import LEVELS, SYMBOLS


def generate_password(level: str, length: int | None = None) -> str:
    """Generate a password for the selected level.

    BAD is intentionally a basic educational mode. Other modes guarantee
    the character categories appropriate to that mode.
    """
    if level not in LEVELS:
        raise ValueError("Unknown security level.")

    config = LEVELS[level]
    if length is None:
        length = config["length"]

    minimum = config["minimum"]
    if not isinstance(length, int) or not minimum <= length <= 64:
        raise ValueError(f"Length must be between {minimum} and 64.")

    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    digits = string.digits
    symbols = SYMBOLS

    if config["mode"] == "basic":
        pool = lower + digits
        required = [secrets.choice(lower), secrets.choice(digits)]
    elif config["mode"] == "mixed":
        pool = lower + upper + digits
        required = [
            secrets.choice(lower),
            secrets.choice(upper),
            secrets.choice(digits),
        ]
    else:
        pool = lower + upper + digits + symbols
        required = [
            secrets.choice(lower),
            secrets.choice(upper),
            secrets.choice(digits),
            secrets.choice(symbols),
        ]

    password_chars = required + [
        secrets.choice(pool) for _ in range(length - len(required))
    ]
    secrets.SystemRandom().shuffle(password_chars)
    return "".join(password_chars)
