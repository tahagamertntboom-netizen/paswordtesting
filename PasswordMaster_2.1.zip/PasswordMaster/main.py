"""Application entry point for Password Master."""
import tkinter as tk
from interface import PasswordMasterApp

def main():
    root = tk.Tk()
    PasswordMasterApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
