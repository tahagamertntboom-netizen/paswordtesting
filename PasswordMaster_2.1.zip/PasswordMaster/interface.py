"""Tkinter user interface for Password Master."""
import tkinter as tk

from analyzer import analyze_password, get_rating
from generator import generate_password
from settings import (
    APP_TITLE, APP_VERSION, WINDOW_SIZE, MIN_WIDTH, MIN_HEIGHT,
    BG, CARD, CARD2, GREEN, WHITE, GRAY, RED, BLUE, LEVELS,
    LEVEL_COLORS,
)


class PasswordMasterApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.level = "EXCELLENT"
        self.root.title(f"{APP_TITLE} {APP_VERSION}")
        self.root.geometry(WINDOW_SIZE)
        self.root.minsize(MIN_WIDTH, MIN_HEIGHT)
        self.root.configure(bg=BG)
        self.root.bind("<F11>", lambda event: self.toggle_fullscreen())
        self.root.bind("<Escape>", self.exit_fullscreen)
        self.show_home()

    # ---------- Shared UI helpers ----------

    def clear(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def toggle_fullscreen(self):
        self.root.attributes(
            "-fullscreen",
            not self.root.attributes("-fullscreen")
        )

    def exit_fullscreen(self, _event=None):
        self.root.attributes("-fullscreen", False)

    def make_label(self, parent, text, size=12, color=WHITE, bold=False):
        return tk.Label(
            parent,
            text=text,
            bg=parent["bg"],
            fg=color,
            font=("Segoe UI", size, "bold" if bold else "normal"),
        )

    def make_button(self, parent, text, command, color=CARD2, fg=WHITE):
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=color,
            fg=fg,
            activebackground=GREEN,
            activeforeground=BG,
            font=("Segoe UI", 11, "bold"),
            relief="flat",
            cursor="hand2",
            padx=18,
            pady=11,
            bd=0,
        )

    def make_card(self, parent, padding=25):
        return tk.Frame(parent, bg=CARD, padx=padding, pady=padding)

    def header(self):
        top = tk.Frame(self.root, bg=BG)
        top.pack(fill="x", padx=30, pady=18)
        self.make_label(top, APP_TITLE, 22, GREEN, True).pack(side="left")
        self.make_label(
            top, f"VERSION {APP_VERSION}", 9, GRAY, True
        ).pack(side="left", padx=12)
        self.make_button(
            top, "FULLSCREEN  F11", self.toggle_fullscreen
        ).pack(side="right")

    def footer(self):
        self.make_label(
            self.root,
            "PASSWORD MASTER  |  SECURE GENERATION SYSTEM",
            9,
            GRAY,
        ).pack(side="bottom", pady=10)

    # ---------- Home and navigation ----------

    def show_home(self):
        self.clear()
        self.header()
        self.make_label(
            self.root, "CREATE YOUR PASSWORD", 27, WHITE, True
        ).pack(pady=(32, 5))
        self.make_label(
            self.root, "Choose your security level", 12, GRAY
        ).pack()

        cards = tk.Frame(self.root, bg=BG)
        cards.pack(pady=32)

        descriptions = {
            "BAD": "Basic protection",
            "GOOD": "Standard protection",
            "EXCELLENT": "Strong protection",
            "GOD": "Maximum generation",
        }

        for name, config in LEVELS.items():
            color = LEVEL_COLORS[name]
            card = tk.Frame(
                cards, bg=CARD, width=195, height=190,
                highlightbackground=color, highlightthickness=1,
            )
            card.pack(side="left", padx=7)
            card.pack_propagate(False)

            self.make_label(card, name, 18, color, True).pack(pady=(23, 9))
            self.make_label(card, descriptions[name], 10, GRAY).pack()
            self.make_label(
                card, f"{config['length']} CHARACTERS", 9, GRAY
            ).pack(pady=7)
            self.make_button(
                card, "SELECT",
                lambda selected=name: self.choose_mode(selected),
                color, BG,
            ).pack(pady=10)

        self.make_label(
            self.root, "POWERFUL PASSWORDS. BETTER SECURITY.",
            11, GREEN, True,
        ).pack(pady=20)
        self.footer()

    def choose_mode(self, selected):
        self.level = selected
        self.clear()
        self.header()

        self.make_label(
            self.root, f"{selected} MODE", 28, GREEN, True
        ).pack(pady=(65, 10))
        self.make_label(
            self.root, LEVELS[selected]["description"], 12, GRAY
        ).pack()

        box = self.make_card(self.root, 35)
        box.pack(pady=35)

        self.make_button(
            box, "WRITE MY PASSWORD", self.manual_page, BLUE
        ).pack(fill="x", pady=12)
        self.make_button(
            box, "AUTO GENERATE", self.automatic_page, GREEN, BG
        ).pack(fill="x", pady=12)
        self.make_button(
            self.root, "BACK TO HOME", self.show_home
        ).pack()
        self.footer()

    # ---------- Analysis page ----------

    def show_analysis(self, password):
        if not password:
            return

        result = analyze_password(password)
        score = result["score"]
        rating, color = get_rating(score)

        self.clear()
        self.header()
        self.make_label(
            self.root, "PASSWORD ANALYSIS", 25, WHITE, True
        ).pack(pady=22)

        box = self.make_card(self.root, 28)
        box.pack(fill="x", padx=70)

        self.make_label(
            box, "ESTIMATED SECURITY SCORE", 12, GRAY, True
        ).pack()
        self.make_label(
            box, f"{score} / 100", 34, color, True
        ).pack(pady=8)

        bar_bg = tk.Frame(box, bg=CARD2, height=16)
        bar_bg.pack(fill="x", pady=12)
        bar = tk.Frame(bar_bg, bg=color, height=16)
        bar.place(relx=0, rely=0, relheight=1, relwidth=score / 100)

        self.make_label(box, rating, 17, color, True).pack(pady=7)

        tk.Frame(box, bg=CARD2, height=1).pack(fill="x", pady=12)
        self.make_label(
            box, "PASSWORD INFORMATION", 11, GREEN, True
        ).pack()
        self.make_label(
            box, f"Length: {result['length']} characters", 10, GRAY
        ).pack(pady=3)
        self.make_label(
            box, f"Estimated entropy: {result['entropy']:.1f} bits",
            10, GRAY,
        ).pack(pady=3)

        self.make_label(
            box, "SECURITY RECOMMENDATIONS", 11, GREEN, True
        ).pack(pady=(16, 7))

        if result["tips"]:
            for tip in result["tips"]:
                self.make_label(box, "- " + tip, 10, GRAY).pack(anchor="w", pady=2)
        else:
            self.make_label(
                box, "No basic weaknesses detected.", 10, GREEN
            ).pack()

        self.make_label(
            box,
            "Note: This score is an educational estimate, not a security guarantee.",
            9, GRAY,
        ).pack(pady=(14, 0))

        self.make_button(
            self.root, "BACK TO HOME", self.show_home
        ).pack(pady=18)
        self.footer()

    # ---------- Manual password page ----------

    def manual_page(self):
        self.clear()
        self.header()
        self.make_label(
            self.root, "ENTER YOUR PASSWORD", 25, WHITE, True
        ).pack(pady=32)

        box = self.make_card(self.root, 30)
        box.pack(fill="x", padx=70)

        self.make_label(
            box, "YOUR PASSWORD", 12, GRAY, True
        ).pack()

        entry = tk.Entry(
            box, font=("Consolas", 18), bg=CARD2, fg=WHITE,
            insertbackground=GREEN, relief="flat",
            justify="center", show="*",
        )
        entry.pack(fill="x", pady=20, ipady=12)
        entry.focus_set()

        show = tk.BooleanVar(value=False)
        tk.Checkbutton(
            box, text="Show password", variable=show,
            command=lambda: entry.config(show="" if show.get() else "*"),
            bg=CARD, fg=GRAY, selectcolor=CARD2,
            activebackground=CARD, activeforeground=GREEN,
        ).pack()

        error = tk.Label(
            box, text="", bg=CARD, fg=RED,
            font=("Segoe UI", 10),
        )
        error.pack(pady=5)

        def check():
            password = entry.get()
            if not password:
                error.config(text="Please enter a password.")
                return
            self.show_analysis(password)

        self.make_button(
            box, "ANALYZE PASSWORD", check, GREEN, BG
        ).pack(pady=20)
        entry.bind("<Return>", lambda _event: check())

        self.make_button(
            self.root, "BACK", lambda: self.choose_mode(self.level)
        ).pack(pady=18)
        self.footer()

    # ---------- Automatic generator page ----------

    def automatic_page(self):
        self.clear()
        self.header()
        self.make_label(
            self.root, "YOUR GENERATED PASSWORD", 24, WHITE, True
        ).pack(pady=25)

        box = self.make_card(self.root, 28)
        box.pack(fill="x", padx=65)

        self.make_label(
            box, "PASSWORD LENGTH", 11, GRAY, True
        ).pack()

        length_var = tk.IntVar(value=LEVELS[self.level]["length"])
        length_control = tk.Spinbox(
            box,
            from_=LEVELS[self.level]["minimum"],
            to=64,
            textvariable=length_var,
            width=8,
            justify="center",
            font=("Segoe UI", 13),
            bg=CARD2,
            fg=GREEN,
            buttonbackground=CARD2,
            relief="flat",
        )
        length_control.pack(pady=10, ipady=5)

        result_var = tk.StringVar()
        display = tk.Entry(
            box, textvariable=result_var, state="readonly",
            readonlybackground=CARD2, fg=GREEN,
            font=("Consolas", 17, "bold"),
            justify="center", relief="flat",
        )
        display.pack(fill="x", pady=18, ipady=14)

        score_label = tk.Label(
            box, text="", bg=CARD, fg=GREEN,
            font=("Segoe UI", 14, "bold"),
        )
        score_label.pack(pady=7)

        status = tk.Label(
            box, text="", bg=CARD, fg=GRAY,
            font=("Segoe UI", 10),
        )
        status.pack(pady=5)

        def generate():
            try:
                length = int(length_var.get())
                password = generate_password(self.level, length)
                result_var.set(password)

                analysis = analyze_password(password)
                rating, color = get_rating(analysis["score"])
                score_label.config(
                    text=f"{rating}  |  {analysis['score']}/100",
                    fg=color,
                )
                status.config(
                    text=f"Estimated entropy: {analysis['entropy']:.1f} bits",
                    fg=GRAY,
                )
            except (ValueError, TypeError):
                result_var.set("")
                score_label.config(text="Invalid password length", fg=RED)
                status.config(
                    text=f"Enter a whole number from {LEVELS[self.level]['minimum']} to 64.",
                    fg=RED,
                )

        def copy_password():
            password = result_var.get()
            if not password:
                status.config(text="Generate a password first.", fg=RED)
                return
            self.root.clipboard_clear()
            self.root.clipboard_append(password)
            self.root.update()
            status.config(text="Password copied to clipboard!", fg=GREEN)

        self.make_button(
            box, "GENERATE PASSWORD", generate, BLUE
        ).pack(fill="x", pady=7)
        self.make_button(
            box, "COPY PASSWORD", copy_password, GREEN, BG
        ).pack(fill="x", pady=7)

        self.make_button(
            self.root, "BACK TO HOME", self.show_home
        ).pack(pady=18)
        self.footer()
        generate()
