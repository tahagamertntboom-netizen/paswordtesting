"""Shared application settings and visual theme."""

APP_TITLE = "PASSWORD MASTER"
APP_VERSION = "2.1"
WINDOW_SIZE = "1000x720"
MIN_WIDTH = 780
MIN_HEIGHT = 620

BG = "#090d18"
CARD = "#111a2b"
CARD2 = "#18243a"
GREEN = "#00e69a"
WHITE = "#f2f6ff"
GRAY = "#8795ad"
RED = "#ff526b"
BLUE = "#4b91ff"
YELLOW = "#ffb84d"

SYMBOLS = "!@#$%^&*_-+=?"

LEVELS = {
    "BAD": {
        "length": 8,
        "minimum": 8,
        "description": "Basic protection - educational only",
        "mode": "basic",
    },
    "GOOD": {
        "length": 12,
        "minimum": 12,
        "description": "Standard protection",
        "mode": "mixed",
    },
    "EXCELLENT": {
        "length": 18,
        "minimum": 16,
        "description": "Strong protection",
        "mode": "strong",
    },
    "GOD": {
        "length": 28,
        "minimum": 20,
        "description": "Maximum generation strength",
        "mode": "strong",
    },
}

LEVEL_COLORS = {
    "BAD": RED,
    "GOOD": YELLOW,
    "EXCELLENT": BLUE,
    "GOD": GREEN,
}
