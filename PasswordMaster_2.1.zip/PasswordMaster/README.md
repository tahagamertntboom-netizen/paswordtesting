# Password Master 2.1

A lightweight desktop password generator and educational password-strength analyzer built with Python and Tkinter.

## Features

- Cryptographically secure password generation using Python's `secrets` module.
- Four generation levels: BAD, GOOD, EXCELLENT, and GOD.
- Adjustable password length.
- Manual password analysis.
- Approximate entropy estimation.
- Basic checks for common passwords, repeated characters, and sequences.
- Dark Tkinter interface.
- No third-party Python packages required.

## Requirements

- Python 3.10 or newer
- Tkinter (normally included with standard Windows Python installations)

## Run

```bash
python main.py
```

## Project structure

```text
PasswordMaster/
├── main.py
├── interface.py
├── generator.py
├── analyzer.py
├── security.py
├── settings.py
├── README.md
├── requirements.txt
└── .gitignore
```

## Important security note

The strength score and entropy value are educational estimates, not a guarantee of password security. The analyzer cannot know whether a password was generated randomly or chosen by a person. Do not enter real, currently used passwords into software you do not fully trust.

The BAD level is intentionally basic and is not recommended for real accounts.
